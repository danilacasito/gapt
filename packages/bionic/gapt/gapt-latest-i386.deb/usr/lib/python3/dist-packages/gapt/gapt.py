def main():
    arch = "i386"
    dist = input("Your Ubuntu/Debian Version Codename> ")
    import os
    print("Welcome to GAPT package manager")
    print("Still in Development!")
    package = input("install> ")
    os.system("wget http://raw.githubusercontent.com/danilacasito/gapt/latest/packages/"+dist+"/"+package+"/"+package+"-latest-"+arch+".deb")
    os.system("sudo dpkg -i "+package+"-latest.deb")
if __name__ == __main__:
    main()
